MIT License.

- We don't responsibility for any damage or inadequate use.

	Templates by Bootstrap framework.
	Icons by Fatcow under CC Attribution 3.0 License. (http://www.fatcow.com/free-icons)


2020. 
enjoy

